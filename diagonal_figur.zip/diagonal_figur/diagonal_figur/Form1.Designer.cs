﻿namespace diagonal_figur
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnYellow = new System.Windows.Forms.Button();
            this.btnLime = new System.Windows.Forms.Button();
            this.btnDarkturkuas = new System.Windows.Forms.Button();
            this.btnforestgreen = new System.Windows.Forms.Button();
            this.btn_check = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbxAntal = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnYellow
            // 
            this.btnYellow.BackColor = System.Drawing.Color.Orange;
            this.btnYellow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYellow.Location = new System.Drawing.Point(43, 264);
            this.btnYellow.Name = "btnYellow";
            this.btnYellow.Size = new System.Drawing.Size(55, 43);
            this.btnYellow.TabIndex = 3;
            this.btnYellow.UseVisualStyleBackColor = false;
            this.btnYellow.Click += new System.EventHandler(this.btnYellow_Click);
            // 
            // btnLime
            // 
            this.btnLime.BackColor = System.Drawing.Color.Lime;
            this.btnLime.Location = new System.Drawing.Point(104, 264);
            this.btnLime.Name = "btnLime";
            this.btnLime.Size = new System.Drawing.Size(55, 43);
            this.btnLime.TabIndex = 6;
            this.btnLime.UseVisualStyleBackColor = false;
            this.btnLime.Click += new System.EventHandler(this.btnLime_Click_1);
            // 
            // btnDarkturkuas
            // 
            this.btnDarkturkuas.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnDarkturkuas.Location = new System.Drawing.Point(165, 264);
            this.btnDarkturkuas.Name = "btnDarkturkuas";
            this.btnDarkturkuas.Size = new System.Drawing.Size(55, 43);
            this.btnDarkturkuas.TabIndex = 5;
            this.btnDarkturkuas.UseVisualStyleBackColor = false;
            this.btnDarkturkuas.Click += new System.EventHandler(this.btnDarkturkuas_Click_1);
            // 
            // btnforestgreen
            // 
            this.btnforestgreen.BackColor = System.Drawing.Color.ForestGreen;
            this.btnforestgreen.Location = new System.Drawing.Point(226, 264);
            this.btnforestgreen.Name = "btnforestgreen";
            this.btnforestgreen.Size = new System.Drawing.Size(55, 43);
            this.btnforestgreen.TabIndex = 6;
            this.btnforestgreen.UseVisualStyleBackColor = false;
            this.btnforestgreen.Click += new System.EventHandler(this.btnforestgreen_Click_1);
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(291, 284);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(100, 23);
            this.btn_check.TabIndex = 7;
            this.btn_check.Text = "Check!";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click_2);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Antal:";
            // 
            // tbxAntal
            // 
            this.tbxAntal.Location = new System.Drawing.Point(76, 13);
            this.tbxAntal.Margin = new System.Windows.Forms.Padding(4);
            this.tbxAntal.Name = "tbxAntal";
            this.tbxAntal.Size = new System.Drawing.Size(205, 20);
            this.tbxAntal.TabIndex = 9;
            this.tbxAntal.TextChanged += new System.EventHandler(this.tbxAntal_TextChanged_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(291, 13);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 25);
            this.button1.TabIndex = 1;
            this.button1.Text = "Rita";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(424, 336);
            this.Controls.Add(this.btnYellow);
            this.Controls.Add(this.btnLime);
            this.Controls.Add(this.btnDarkturkuas);
            this.Controls.Add(this.btnforestgreen);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxAntal);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Uppgift 10.4b";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnYellow;
        private System.Windows.Forms.Button btnLime;
        private System.Windows.Forms.Button btnDarkturkuas;
        private System.Windows.Forms.Button btnforestgreen;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxAntal;
        private System.Windows.Forms.Button button1;
    }
}

